import { CanActivate, 
    ActivatedRouteSnapshot, 
    RouterStateSnapshot, 
    Router, 
    CanActivateChild } from "@angular/router";
import { Observable, Observer } from 'rxjs';
import { AuthService } from "./auth.service";
import { Injectable } from "@angular/core";

@Injectable()
export class AuthGaurdService implements CanActivate, CanActivateChild {

    constructor(private authService:AuthService, private router:Router){}

    canActivate(route:ActivatedRouteSnapshot, state:RouterStateSnapshot) 
        : Observable<boolean> | Promise<boolean> | boolean {
            return Observable.create((observer:Observer<boolean>)=>{
                this.authService.isAuthenticated().subscribe((authenticated:boolean)=>{
                    if(authenticated) {
                        observer.next(authenticated);
                    }
                    else {
                        this.router.navigate(['/']);
                    }
                });
            });
    }

    canActivateChild(route:ActivatedRouteSnapshot, state:RouterStateSnapshot) 
    : Observable<boolean> | Promise<boolean> | boolean {
        return this.canActivate(route,state);
    }
}