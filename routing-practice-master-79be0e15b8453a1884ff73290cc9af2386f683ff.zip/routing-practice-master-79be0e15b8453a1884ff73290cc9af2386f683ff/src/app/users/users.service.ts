export class UsersService {
  private users = [
    {
      id: 1,
      name: 'Kevin'
    },
    {
      id: 2,
      name: 'David'
    },
    {
      id: 3,
      name: 'Stephanie'
    }
  ];

  getUsers() {
    return this.users;
  }

  getUser(id: number) {
    const user = this.users.find(
      (s) => {
        return s.id === +id;
      }
    );
    return user;
  }

  updateUser(id: number, userInfo: {id: number, name: string}) {
    const user = this.users.find(
      (s) => {
        return s.id === id;
      }
    );
    if (user) {
      user.id = userInfo.id;
      user.name = userInfo.name;
    }
  }
}
