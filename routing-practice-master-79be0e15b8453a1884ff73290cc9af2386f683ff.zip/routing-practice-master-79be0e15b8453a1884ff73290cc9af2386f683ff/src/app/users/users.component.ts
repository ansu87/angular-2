import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UsersService } from './users.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent {

  users = [];

  constructor(private usersService:UsersService, 
    private router:Router, 
    private route:ActivatedRoute){
  }

  ngOnInit(){
    this.users = this.usersService.getUsers();
  }

  onReload(){
//    this.router.navigate(['../users'], {relativeTo:this.route});
    this.router.navigate(['../users'], {queryParams: {status:'active'}, fragment: 'Loading'});
  }
}
