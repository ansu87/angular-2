import { Observable, Observer } from "rxjs";

export class AuthService {
    
    loggedIn = true;

    login(){
        this.loggedIn = true;
    }

    logOut(){
        this.loggedIn = false;
    }

    isAuthenticated(){
        return Observable.create((observer:Observer<boolean>)=>{
            setTimeout(() => {
                observer.next(this.loggedIn);    
            }, 500);
        });
    }
}