import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from './home/home.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { AuthGaurdService } from './auth-gaurd.service';
import { UsersComponent } from './users/users.component';
import { EditUserComponent } from './users/edit-user/edit-user.component';
import { UserComponent } from './users/user/user.component';

const appRoutes: Routes = [
    {path:'', component: HomeComponent},
    {path:'not-found', component: NotFoundComponent},
    {path:'users', canActivateChild: [AuthGaurdService], component: UsersComponent, children: [
      {path:':id/edit', component: EditUserComponent},
      {path:':id/:name', component: UserComponent}
    ]},
    {path:'**', redirectTo: 'not-found'}
  ]

@NgModule({
    imports: [
        RouterModule.forRoot(appRoutes)
    ],
    exports: [RouterModule]
})
export class AppRoutingModule {

}