import { Component, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnChanges{

  arr = [1,2,3,4,5];
  value = 10;

  constructor() {
    console.log('constructor called');
  }

  ngOnChanges(changes:SimpleChanges){
    console.log(changes);
  }

  ngOnInit() {
    console.log('ngOnInit called');
  }

  ngDoCheck() {
    console.log('ngDoCheck called');
    
  }

}
