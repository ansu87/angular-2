import { Component, OnInit, ElementRef, ContentChild } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent {

  products = []

  @ContentChild('copyrightParagraph') copyright:ElementRef;

  addProduct(data:any){
    this.products.push(data);
  }

  deleteProduct(data:any){
    this.products = this.products.filter(p=>p.title!==data.name);
  }
}
