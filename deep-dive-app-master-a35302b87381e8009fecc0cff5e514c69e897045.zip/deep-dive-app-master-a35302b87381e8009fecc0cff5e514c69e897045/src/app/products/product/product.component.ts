import { Component, Input, EventEmitter, Output, SimpleChanges } from "@angular/core";

@Component({
    selector: 'app-product',
    templateUrl: 'product.component.html',
    styleUrls: ['product.component.css']
})
export class ProductComponent {

   @Input('title') name:string;
   @Input('description') desc:string;

   @Output() productDeleted = new EventEmitter<{name:string}>();

    ngOnChanges(changes:SimpleChanges) {
        console.log(changes);
    }

    ngOnDestroy() {
        console.log('ngOnDestror called'); 
    }

    deleteProduct(name:string){
        this.productDeleted.emit({name});
    }

}