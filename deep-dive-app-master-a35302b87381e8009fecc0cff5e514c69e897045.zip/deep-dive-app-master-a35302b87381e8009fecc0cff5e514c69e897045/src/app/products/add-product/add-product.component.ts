import { Component, EventEmitter, Output, ElementRef, ViewChild } from "@angular/core";

@Component({
    selector: 'app-add-product',
    templateUrl: 'add-product.component.html',
    styleUrls: ['add-product.component.css']
})
export class AddProductComponent {

    // name:string;
    // desc:string;
    //descInput
    @ViewChild('descInput') descElement:ElementRef;

    @Output() productAdded = new EventEmitter<{title:string,desc:string}>();
   
    // addProduct() {
    //     this.productAdded.emit({title:this.name,desc:this.desc});
    // }

    addProduct(nameInput:HTMLInputElement) {
        this.productAdded.emit({title:nameInput.value,desc:this.descElement.nativeElement.value});
    }
}