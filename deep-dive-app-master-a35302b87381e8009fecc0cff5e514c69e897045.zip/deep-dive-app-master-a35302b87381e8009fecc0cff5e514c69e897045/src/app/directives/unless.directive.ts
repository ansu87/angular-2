import { Directive, TemplateRef, ViewContainerRef, Input } from "@angular/core";

@Directive({
    selector: '[appUnless]'
})
export class UnlessDirective {

    constructor(private templateRef:TemplateRef<any>, private vcRef:ViewContainerRef){}

    @Input() set appUnless(condition:boolean){
        if(condition){
            //embed the template content into the view container ref
            this.vcRef.createEmbeddedView(this.templateRef);
        } else {
            this.vcRef.clear();
        }
    }
}