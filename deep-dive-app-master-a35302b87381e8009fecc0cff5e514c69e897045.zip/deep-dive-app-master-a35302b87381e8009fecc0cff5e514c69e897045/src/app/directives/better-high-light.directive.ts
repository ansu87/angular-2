import { Directive, ElementRef, Renderer2, HostListener, HostBinding, Input } from "@angular/core";

@Directive({
    selector: '[appBetterHighLight]'
})
export class BetterHighLightDirective{

    @Input() highLight:string = '#ddd';
    @Input() noHighLight:string = '#666';

    @HostBinding('style.backgroundColor') backgroundColor:string;

    // constructor(private elemRef:ElementRef, private renderer: Renderer2){}

    ngOnInit() {
        // this.renderer.setStyle(this.elemRef.nativeElement, 'background-color', 'blue');
        this.backgroundColor = this.noHighLight;
    }

    @HostListener('mouseenter') mouseOver(eventData:Event){
        //this.renderer.setStyle(this.elemRef.nativeElement, 'background-color', 'green');
        this.backgroundColor = this.highLight;
    }
    @HostListener('mouseleave') mouseLeft(eventData:Event){
        //this.renderer.setStyle(this.elemRef.nativeElement, 'background-color', '#999');
        this.backgroundColor = this.noHighLight;
    }

    
}