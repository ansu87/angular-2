import { Component } from '@angular/core';

@Component({
  //make sure not conflict with other modules and unique within app
  // selector: 'app-root', //element selector
  // selector: '[app-root]',  //property selector
  selector: 'app-root', //class selector 
  templateUrl: './app.component.html',
  // template: `<div>
  //   <h1>Learning Calendar</h1>
  //   <div>Learning Angular</div>
  //   <h1>Learning Calendar</h1>
  //   <div>Learning Angular</div>`,
  styleUrls: ['./app.component.css']
  // styles: [`
  // div { color: green; }
  // div:hover { background-color: red; }
  // `]
})
export class AppComponent {
  title = 'Cognizant';
  showMessage:boolean = false;
  high = false;

  arr = [1,2,3,4];

  bgColor = 'blue';

  getColor() {
    return Math.random() > 0.5 ? 'red' : 'green';
  }

}