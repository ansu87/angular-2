import { Component, EventEmitter, Output, ElementRef, ViewChild } from "@angular/core";

@Component({
    selector: 'app-product-form',
    templateUrl: 'product-form.component.html',
    styleUrls: ['product-form.component.css']
})
export class ProductFormComponent {
//    title:string;
//    desc:string;

    @ViewChild('titleInput') title:ElementRef;
    @ViewChild('descInput') desc:ElementRef;
   
    @Output() productAdded = new EventEmitter<{title:string,desc:string}>();

    //using 2-way binding
//    onProductAdd() {
//     this.productAdded.emit({title:this.title, desc:this.desc});
//    }

    //using local reference
//    onProductAdd(title:HTMLInputElement, desc:HTMLInputElement) {
//     this.productAdded.emit({title:title.value, desc:desc.value});
//    }

    //using ViewChild
   onProductAdd() {
    this.productAdded.emit({
        title:this.title.nativeElement.value, 
        desc:this.desc.nativeElement.value});
   }
}