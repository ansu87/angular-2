import { Component } from "@angular/core";

@Component({
    selector: 'app-products',
    templateUrl: 'products.component.html',
    styleUrls: ['products.component.css']
})
export class ProductsComponent {

    // products = [{title:'Some',desc:'Testing'}];
    products = [];
  
    addProduct(data:any){
        this.products.push(data);
    }

    deleteProduct(data:any) {
        this.products = this.products.filter(p => p.title !== data.title);
    }
}