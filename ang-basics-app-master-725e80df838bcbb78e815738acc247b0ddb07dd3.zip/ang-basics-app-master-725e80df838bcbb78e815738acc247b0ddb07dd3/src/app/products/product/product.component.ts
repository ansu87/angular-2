import { Component, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent {

  @Input('item') product = {title:String, desc:String};
  @Output() productDeleted = new EventEmitter<{title:string}>();

  onDeleteProduct() {
    this.productDeleted.emit({title:this.product.title.toString()});
  }

}
