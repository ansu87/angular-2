export class ProductsService {
  private products = [
    {
      id: 1,
      name: 'Drone',
      status: 'available'
    },
    {
      id: 2,
      name: 'Robot',
      status: 'no stock'
    },
    {
      id: 3,
      name: 'Sensor',
      status: 'nostock'
    }
  ];

  getProducts() {
    return this.products;
  }

  getProduct(id: number) {
    const product = this.products.find(
      (s) => {
        return s.id === id;
      }
    );
    return product;
  }

  updateProduct(id: number, productInfo: {name: string, status: string}) {
    const product = this.products.find(
      (s) => {
        return s.id === id;
      }
    );
    if (product) {
      product.name = productInfo.name;
      product.status = productInfo.status;
    }
  }
}
